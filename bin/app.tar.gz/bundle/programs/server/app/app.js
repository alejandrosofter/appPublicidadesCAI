var require = meteorInstall({"lib":{"collections.js":function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                           //
// lib/collections.js                                                                                        //
//                                                                                                           //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                             //
Settings = new Mongo.Collection('settings');                                                                 // 1
Publicidades = new Mongo.Collection('publicidades');                                                         // 2
Socios = new Mongo.Collection('socios');                                                                     // 3
Socios.attachSchema(new SimpleSchema({                                                                       // 5
  _id: {                                                                                                     // 6
    type: String,                                                                                            // 7
    label: "ID"                                                                                              // 8
  },                                                                                                         // 6
  nombreSocio: {                                                                                             // 10
    type: String,                                                                                            // 11
    optional: false,                                                                                         // 12
    label: 'Nombres'                                                                                         // 13
  },                                                                                                         // 10
  nroSocio: {                                                                                                // 15
    type: String,                                                                                            // 16
    label: 'Nro Socio'                                                                                       // 17
  },                                                                                                         // 15
  estado: {                                                                                                  // 19
    type: String,                                                                                            // 20
    label: 'Estado'                                                                                          // 21
  },                                                                                                         // 19
  alDia: {                                                                                                   // 23
    type: Boolean,                                                                                           // 24
    label: 'Esta al dia?'                                                                                    // 25
  }                                                                                                          // 23
}));                                                                                                         // 5
Publicidades.attachSchema(new SimpleSchema({                                                                 // 29
  idUsuario: {                                                                                               // 30
    type: String,                                                                                            // 31
    label: "Comercio",                                                                                       // 32
    optional: true,                                                                                          // 33
    autoform: {                                                                                              // 34
      type: "select2",                                                                                       // 36
      select2Options: {                                                                                      // 38
        placeholder: 'Comercio...',                                                                          // 39
        width: "400px",                                                                                      // 40
        allowClear: true                                                                                     // 41
      }                                                                                                      // 38
    }                                                                                                        // 34
  },                                                                                                         // 30
  fecha: {                                                                                                   // 45
    type: Date,                                                                                              // 46
    autoform: {                                                                                              // 47
      style: "width:160px",                                                                                  // 48
      defaultValue: new Date()                                                                               // 49
    },                                                                                                       // 47
    optional: false,                                                                                         // 51
    label: 'Fecha'                                                                                           // 52
  },                                                                                                         // 45
  detalle: {                                                                                                 // 54
    type: String,                                                                                            // 55
    label: 'Detalle'                                                                                         // 56
  },                                                                                                         // 54
  tipoDescuento: {                                                                                           // 58
    type: String,                                                                                            // 59
    label: 'Tipo descuento'                                                                                  // 60
  },                                                                                                         // 58
  cantidadDescuento: {                                                                                       // 62
    type: String,                                                                                            // 63
    label: 'Cant. descuento'                                                                                 // 64
  },                                                                                                         // 62
  detalleSlide: {                                                                                            // 66
    type: String,                                                                                            // 67
    label: 'Detalle Slide'                                                                                   // 68
  },                                                                                                         // 66
  muestraSlide: {                                                                                            // 70
    type: Boolean,                                                                                           // 71
    label: 'Muestra en Slide'                                                                                // 72
  },                                                                                                         // 70
  logo: {                                                                                                    // 74
    type: String,                                                                                            // 75
    label: 'Logo'                                                                                            // 76
  },                                                                                                         // 74
  videoYoutube: {                                                                                            // 78
    type: String,                                                                                            // 79
    label: 'Video',                                                                                          // 80
    optional: true                                                                                           // 81
  },                                                                                                         // 78
  estado: {                                                                                                  // 83
    type: String,                                                                                            // 84
    optional: true,                                                                                          // 85
    label: "Estado",                                                                                         // 86
    autoform: {                                                                                              // 88
      defaultValue: "PENDIENTE",                                                                             // 89
      type: "select-radio-inline",                                                                           // 90
      trueLabel: "Yes",                                                                                      // 91
      falseLabel: "No",                                                                                      // 91
      options: [{                                                                                            // 92
        label: "ACTIVO",                                                                                     // 93
        value: "ACTIVO"                                                                                      // 93
      }, {                                                                                                   // 93
        label: "INACTIVO",                                                                                   // 94
        value: "INACTIVO"                                                                                    // 94
      }]                                                                                                     // 94
    }                                                                                                        // 88
  },                                                                                                         // 83
  usoSocios: {                                                                                               // 99
    type: Array,                                                                                             // 100
    optional: true,                                                                                          // 101
    label: "Uso Socios"                                                                                      // 102
  },                                                                                                         // 99
  "usoSocios.$": {                                                                                           // 105
    type: Object                                                                                             // 106
  },                                                                                                         // 105
  "usoSocios.$._id": {                                                                                       // 108
    type: String,                                                                                            // 110
    autoValue: function () {                                                                                 // 111
      return Meteor.uuid();                                                                                  // 112
    }                                                                                                        // 113
  },                                                                                                         // 108
  "usoSocios.$.fecha": {                                                                                     // 116
    type: Date,                                                                                              // 117
    optional: false,                                                                                         // 118
    label: "Fecha"                                                                                           // 119
  },                                                                                                         // 116
  "usoSocios.$.idSocio": {                                                                                   // 121
    type: String,                                                                                            // 122
    optional: true,                                                                                          // 123
    label: "Socio"                                                                                           // 124
  },                                                                                                         // 121
  "usoSocios.$.idPromocion": {                                                                               // 126
    type: String,                                                                                            // 127
    optional: true,                                                                                          // 128
    label: "Promocion"                                                                                       // 129
  },                                                                                                         // 126
  promociones: {                                                                                             // 131
    type: Array,                                                                                             // 132
    optional: true,                                                                                          // 133
    label: "Promociones"                                                                                     // 134
  },                                                                                                         // 131
  "promociones.$": {                                                                                         // 137
    type: Object                                                                                             // 138
  },                                                                                                         // 137
  "promociones.$._id": {                                                                                     // 140
    type: String,                                                                                            // 142
    autoValue: function () {                                                                                 // 143
      return Meteor.uuid();                                                                                  // 144
    }                                                                                                        // 145
  },                                                                                                         // 140
  //  "promociones.$.fechaHasta": {                                                                          // 149
  //   type: Date,                                                                                           // 150
  //   label:"Fecha Hasta"                                                                                   // 152
  // },                                                                                                      // 153
  "promociones.$.detalle": {                                                                                 // 154
    type: String,                                                                                            // 155
    optional: false,                                                                                         // 156
    label: "Detalle"                                                                                         // 157
  },                                                                                                         // 154
  "promociones.$.ahorroEn": {                                                                                // 159
    type: String,                                                                                            // 160
    optional: false,                                                                                         // 161
    label: "Ahorro En..."                                                                                    // 162
  },                                                                                                         // 159
  "promociones.$.cantidad": {                                                                                // 164
    type: String,                                                                                            // 165
    optional: false,                                                                                         // 166
    label: "Cantidad"                                                                                        // 167
  },                                                                                                         // 164
  "promociones.$.logo": {                                                                                    // 169
    type: String,                                                                                            // 170
    optional: true,                                                                                          // 171
    label: "Logo"                                                                                            // 172
  },                                                                                                         // 169
  "promociones.$.cantidaCuotas": {                                                                           // 174
    type: String,                                                                                            // 175
    optional: true,                                                                                          // 176
    label: "Cant. Cuotas"                                                                                    // 177
  },                                                                                                         // 174
  "promociones.$.cantidadCuotas": {                                                                          // 179
    type: String,                                                                                            // 180
    optional: true,                                                                                          // 181
    label: "Cant. Cuotas"                                                                                    // 182
  }                                                                                                          // 179
}, {                                                                                                         // 29
  tracker: Tracker                                                                                           // 187
}));                                                                                                         // 187
///////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"router.js":function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                           //
// lib/router.js                                                                                             //
//                                                                                                           //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                             //
applicationController = RouteController.extend({                                                             // 1
		layoutTemplate: 'layoutApp',                                                                               // 2
		loadingTemplate: 'loaderGral',                                                                             // 3
		notFoundTemlplate: 'notFound',                                                                             // 4
		waitOn: function () {                                                                                      // 6
				return [Meteor.subscribe("publicidades.all")];                                                           // 7
		},                                                                                                         // 10
		onBeforeAction: function (pause) {                                                                         // 11
				this.render('loaderGral');                                                                               // 12
				this.next();                                                                                             // 13
		},                                                                                                         // 14
		action: function () {                                                                                      // 15
				if (!this.ready()) {                                                                                     // 16
						this.render('loaderGral');                                                                             // 17
				} else {                                                                                                 // 18
						this.render();                                                                                         // 20
				}                                                                                                        // 22
		}                                                                                                          // 23
});                                                                                                          // 1
Router.route('/', {                                                                                          // 25
		path: '/',                                                                                                 // 26
		// layoutTemplate: 'layoutVacio',                                                                          // 27
		template: "inicio",                                                                                        // 28
		controller: applicationController                                                                          // 29
});                                                                                                          // 25
Router.route('/inicio', {                                                                                    // 31
		path: '/inicio',                                                                                           // 32
		// layoutTemplate: 'layoutVacio',                                                                          // 33
		template: "inicio",                                                                                        // 34
		controller: applicationController                                                                          // 35
});                                                                                                          // 31
Router.route('settings', {                                                                                   // 38
		path: '/settings',                                                                                         // 39
		template: "settings",                                                                                      // 40
		controller: applicationController                                                                          // 41
});                                                                                                          // 38
Router.route('usuarios', {                                                                                   // 43
		path: '/usuarios',                                                                                         // 44
		template: "usuarios",                                                                                      // 45
		controller: applicationController                                                                          // 46
});                                                                                                          // 43
Router.route('publicidades', {                                                                               // 48
		path: '/publicidades',                                                                                     // 49
		template: "publicidades",                                                                                  // 50
		controller: applicationController                                                                          // 51
});                                                                                                          // 48
Router.route('/editarBanner/:_id', {                                                                         // 53
		controller: applicationController,                                                                         // 54
		template: 'editarBanner',                                                                                  // 55
		data: function () {                                                                                        // 56
				var sal = Publicidades.findOne({                                                                         // 57
						_id: this.params._id                                                                                   // 57
				});                                                                                                      // 57
				return sal;                                                                                              // 58
		}                                                                                                          // 59
});                                                                                                          // 53
Router.route('/liquidaciones_facturas/:_id', {                                                               // 61
		controller: applicationController,                                                                         // 62
		template: 'liquidaciones_facturas',                                                                        // 63
		data: function () {                                                                                        // 64
				var sal = Liquidaciones.findOne({                                                                        // 65
						_id: this.params._id                                                                                   // 65
				});                                                                                                      // 65
				console.log(this.params);                                                                                // 66
				return sal;                                                                                              // 67
		}                                                                                                          // 68
});                                                                                                          // 61
Router.route('/nomencladores/:_id', {                                                                        // 70
		controller: applicationController,                                                                         // 71
		template: 'nomencladores',                                                                                 // 72
		data: function () {                                                                                        // 73
				Meteor.subscribe('nomencladores.all');                                                                   // 74
				var sal = Nomencladores.findOne({                                                                        // 75
						_id: this.params._id                                                                                   // 75
				});                                                                                                      // 75
				return sal;                                                                                              // 76
		}                                                                                                          // 77
});                                                                                                          // 70
///////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"utils.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                           //
// lib/utils.js                                                                                              //
//                                                                                                           //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                             //
/*eslint-disable no-unreachable, no-extend-native, no-undef, semi*/String.prototype.lpad = function (padString, length) {
    var str = this;                                                                                          // 3
                                                                                                             //
    while (str.length < length) {                                                                            // 4
        str = padString + str;                                                                               // 5
    }                                                                                                        // 4
                                                                                                             //
    return str;                                                                                              // 6
};                                                                                                           // 7
                                                                                                             //
Date.prototype.addHours = function (h) {                                                                     // 8
    this.setTime(this.getTime() + h * 60 * 60 * 1000);                                                       // 9
    return this;                                                                                             // 10
};                                                                                                           // 11
                                                                                                             //
Date.prototype.addDays = function (num) {                                                                    // 12
    var value = this.valueOf();                                                                              // 13
    value += 86400000 * num;                                                                                 // 14
    return new Date(value);                                                                                  // 15
};                                                                                                           // 16
                                                                                                             //
String.prototype.lpad = function (padString, length) {                                                       // 17
    var str = this;                                                                                          // 18
                                                                                                             //
    while (str.length < length) {                                                                            // 19
        str = padString + str;                                                                               // 20
    }                                                                                                        // 19
                                                                                                             //
    return str;                                                                                              // 21
};                                                                                                           // 22
                                                                                                             //
String.prototype.capitalizar = function () {                                                                 // 23
    return this.charAt(0).toUpperCase() + this.slice(1);                                                     // 24
};                                                                                                           // 25
                                                                                                             //
String.prototype.rpad = function (padString, length) {                                                       // 26
    var str = this;                                                                                          // 27
                                                                                                             //
    while (str.length < length) {                                                                            // 28
        str = str + padString;                                                                               // 29
    }                                                                                                        // 28
                                                                                                             //
    return str;                                                                                              // 30
};                                                                                                           // 31
                                                                                                             //
Date.prototype.getFecha = function () {                                                                      // 32
    var value = this.valueOf();                                                                              // 33
    value += 86400000 * 1;                                                                                   // 34
    var d = new Date(value);                                                                                 // 35
    return d.getDate() + "/" + (d.getMonth() + 1) + "/" + d.getFullYear();                                   // 36
};                                                                                                           // 37
                                                                                                             //
Date.prototype.getFecha2 = function () {                                                                     // 38
    var value = this.valueOf();                                                                              // 39
    value += 86400000 * 1;                                                                                   // 40
    var d = new Date(value);                                                                                 // 41
    return d.getDate() + "/" + (d.getMonth() + 1) + "/" + d.getFullYear();                                   // 42
};                                                                                                           // 43
                                                                                                             //
Date.prototype.getMes = function () {                                                                        // 44
    var value = this.valueOf();                                                                              // 45
    value += 86400000 * 1;                                                                                   // 46
    var d = new Date(value);                                                                                 // 47
    return d.getMonth() + 1;                                                                                 // 48
};                                                                                                           // 49
                                                                                                             //
Date.prototype.getDia = function () {                                                                        // 50
    var value = this.valueOf();                                                                              // 51
    value += 86400000 * 1;                                                                                   // 52
    var d = new Date(value);                                                                                 // 53
    return d.getDate();                                                                                      // 54
};                                                                                                           // 55
                                                                                                             //
Date.prototype.getMesLetras = function () {                                                                  // 56
    var value = this.valueOf();                                                                              // 57
    var d = new Date(value);                                                                                 // 58
    var meses = ["ENERO", "FEBRERO", "MARZO", "ABRIL", "MAYO", "JUNIO", "JULIO", "AGOSTO", "SEPTEMBRE", "OCTUBRE", "NOVIEMBRE", "DICIEMBRE"];
    return meses[d.getMonth()];                                                                              // 61
};                                                                                                           // 62
                                                                                                             //
Date.prototype.getAno = function () {                                                                        // 63
    var value = this.valueOf();                                                                              // 64
    value += 86400000 * 1;                                                                                   // 65
    var d = new Date(value);                                                                                 // 66
    return d.getFullYear();                                                                                  // 67
};                                                                                                           // 68
                                                                                                             //
Number.prototype.formatMoney = function (n, x, s, c) {                                                       // 69
    var re = '\\d(?=(\\d{' + (x || 3) + '})+' + (n > 0 ? '\\D' : '$') + ')',                                 // 70
        num = this.toFixed(Math.max(0, ~~n));                                                                // 70
    return (c ? num.replace('.', c) : num).replace(new RegExp(re, 'g'), '$&' + (s || ','));                  // 73
};                                                                                                           // 74
                                                                                                             //
function validarLargoCBU(cbu) {                                                                              // 75
    if (cbu.length != 22) {                                                                                  // 76
        return false;                                                                                        // 76
    }                                                                                                        // 76
                                                                                                             //
    return true;                                                                                             // 77
}                                                                                                            // 78
                                                                                                             //
var validarCodigoBanco = function (codigo) {                                                                 // 80
    if (codigo.length != 8) {                                                                                // 81
        return false;                                                                                        // 81
    }                                                                                                        // 81
                                                                                                             //
    var banco = codigo.substr(0, 3);                                                                         // 82
    var digitoVerificador1 = codigo[3];                                                                      // 83
    var sucursal = codigo.substr(4, 3);                                                                      // 84
    var digitoVerificador2 = codigo[7];                                                                      // 85
    var suma = banco[0] * 7 + banco[1] * 1 + banco[2] * 3 + digitoVerificador1 * 9 + sucursal[0] * 7 + sucursal[1] * 1 + sucursal[2] * 3;
    var diferencia = 10 - suma % 10;                                                                         // 89
    return diferencia == digitoVerificador2;                                                                 // 91
};                                                                                                           // 92
                                                                                                             //
mesLetras = function (mes) {                                                                                 // 93
    if (mes == 1) return "ENERO";                                                                            // 95
    if (mes == 2) return "FEBRERO";                                                                          // 96
    if (mes == 3) return "MARZO";                                                                            // 97
    if (mes == 4) return "ABRIL";                                                                            // 98
    if (mes == 5) return "MAYO";                                                                             // 99
    if (mes == 6) return "JUNIO";                                                                            // 100
    if (mes == 7) return "JULIO";                                                                            // 101
    if (mes == 8) return "AGOSTO";                                                                           // 102
    if (mes == 9) return "SEPTEMBRE";                                                                        // 103
    if (mes == 10) return "OCTUBRE";                                                                         // 104
    if (mes == 11) return "NOVIEMBRE";                                                                       // 105
    if (mes == 12) return "DICIEMBRE";                                                                       // 106
    return "s/a";                                                                                            // 107
};                                                                                                           // 108
                                                                                                             //
mesNumeros = function (mes) {                                                                                // 109
    if (mes == "ENERO") return 1;                                                                            // 111
    if (mes == "FEBRERO") return 2;                                                                          // 112
    if (mes == "MARZO") return 3;                                                                            // 113
    if (mes == "ABRIL") return 4;                                                                            // 114
    if (mes == "MAYO") return 5;                                                                             // 115
    if (mes == "JUNIO") return 6;                                                                            // 116
    if (mes == "JULIO") return 7;                                                                            // 117
    if (mes == "AGOSTO") return 8;                                                                           // 118
    if (mes == "SEPTEMBRE") return 9;                                                                        // 119
    if (mes == "OCTUBRE") return 10;                                                                         // 120
    if (mes == "NOVIEMBRE") return 11;                                                                       // 121
    if (mes == "DICIEMBRE") return 12;                                                                       // 122
    return null;                                                                                             // 123
};                                                                                                           // 124
                                                                                                             //
getMeses = function () {                                                                                     // 125
    return ["ENERO", "FEBRERO", "MARZO", "ABRIL", "MAYO", "JUNIO", "JULIO", "AGOSTO", "SEPTEMBRE", "OCTUBRE", "NOVIEMBRE", "DICIEMBRE"];
};                                                                                                           // 128
                                                                                                             //
ripFechaArchivo = function (fechaDate) {                                                                     // 129
    var st = fechaDate.toLocaleDateString();                                                                 // 131
    var arr = st.split("/");                                                                                 // 132
    return arr[0].lpad("0", 2) + arr[1].lpad("0", 2) + arr[2].lpad("0", 2);                                  // 134
};                                                                                                           // 135
                                                                                                             //
getImporteTotalSocios = function (arr) {                                                                     // 136
    var sum = 0;                                                                                             // 138
                                                                                                             //
    for (var i = 0; i < arr.length; i++) {                                                                   // 139
        sum += arr[i].importe * 1;                                                                           // 139
    }                                                                                                        // 139
                                                                                                             //
    return sum;                                                                                              // 140
};                                                                                                           // 141
                                                                                                             //
ripImporteArchivo = function (importe) {                                                                     // 142
    importe = importe + "";                                                                                  // 144
    var arr = importe.split(".");                                                                            // 145
    if (arr.length > 1) return arr[0].lpad("0", 8) + arr[1].lpad("0", 2);                                    // 146
    return arr[0].lpad("0", 8) + "00";                                                                       // 147
};                                                                                                           // 148
                                                                                                             //
var validarCuenta = function (cuenta) {                                                                      // 149
    if (cuenta.length != 14) {                                                                               // 150
        return false;                                                                                        // 150
    }                                                                                                        // 150
                                                                                                             //
    var digitoVerificador = cuenta[13];                                                                      // 151
    var suma = cuenta[0] * 3 + cuenta[1] * 9 + cuenta[2] * 7 + cuenta[3] * 1 + cuenta[4] * 3 + cuenta[5] * 9 + cuenta[6] * 7 + cuenta[7] * 1 + cuenta[8] * 3 + cuenta[9] * 9 + cuenta[10] * 7 + cuenta[11] * 1 + cuenta[12] * 3;
    var diferencia = 10 - suma % 10;                                                                         // 153
    return diferencia == digitoVerificador;                                                                  // 154
};                                                                                                           // 155
                                                                                                             //
validarCBU = function (cbu) {                                                                                // 157
    return validarLargoCBU(cbu) && validarCodigoBanco(cbu.substr(0, 8)) && validarCuenta(cbu.substr(8, 14));
};                                                                                                           // 159
                                                                                                             //
getClaseTipoSocio = function (fechaNac, esActivo, estado) {                                                  // 160
    var tipo = getTipoSocio(fechaNac, esActivo);                                                             // 161
    if (estado == "BAJA") return "bajaSocio";                                                                // 162
    var clase = tipo === "PARTICIPANTE" ? "text-warning" : "text-info";                                      // 163
    if (tipo === "ACTIVO") clase = "text-danger";                                                            // 164
    return clase;                                                                                            // 165
};                                                                                                           // 166
                                                                                                             //
geTipoSocioEdad = function (edad, activo) {                                                                  // 167
    var edadAdherente = parseFloat(Settings.findOne({                                                        // 169
        clave: "edadAdherente"                                                                               // 169
    }).valor);                                                                                               // 169
    if (activo) return "ACTIVO";                                                                             // 170
    if (edad >= edadAdherente) return "ADHERENTE";                                                           // 171
    return "PARTICIPANTE";                                                                                   // 173
};                                                                                                           // 174
                                                                                                             //
getImporteSocioEdad = function (edad, activo) {                                                              // 175
    var edadAdherente = parseFloat(Settings.findOne({                                                        // 177
        clave: "edadAdherente"                                                                               // 177
    }).valor);                                                                                               // 177
    if (activo) return parseFloat(Settings.findOne({                                                         // 178
        clave: "importeActivos"                                                                              // 178
    }).valor);                                                                                               // 178
    if (edad >= edadAdherente) return parseFloat(Settings.findOne({                                          // 179
        clave: "imprteAdherentes"                                                                            // 179
    }).valor);                                                                                               // 179
    return parseFloat(Settings.findOne({                                                                     // 181
        clave: "importeParticipantes"                                                                        // 181
    }).valor);                                                                                               // 181
};                                                                                                           // 182
                                                                                                             //
getEdadSocio = function (fechaNac) {                                                                         // 183
    var hoy = new Date();                                                                                    // 184
    var cumpleanos = new Date(fechaNac);                                                                     // 185
    var edad = hoy.getAno() - cumpleanos.getAno();                                                           // 186
    var m = hoy.getMes() - cumpleanos.getMes();                                                              // 187
                                                                                                             //
    if (m < 0 || m === 0 && hoy.getDia() < cumpleanos.getDia()) {                                            // 189
        edad--;                                                                                              // 190
    }                                                                                                        // 191
                                                                                                             //
    return edad;                                                                                             // 193
};                                                                                                           // 194
                                                                                                             //
getTipoSocio = function (fechaNac, esActivo) {                                                               // 195
    var edadAdherente = parseFloat(Settings.findOne({                                                        // 196
        clave: "edadAdherente"                                                                               // 196
    }).valor);                                                                                               // 196
    var anos = getEdadSocio(fechaNac);                                                                       // 198
    if (esActivo) return "ACTIVO";                                                                           // 199
    return anos < edadAdherente ? "PARTICIPANTE" : "ADHERENTE";                                              // 200
};                                                                                                           // 201
                                                                                                             //
getImporteSocio = function (idSocio) {                                                                       // 202
    var dataParticipantes = Settings.findOne({                                                               // 204
        clave: "importeParticipantes"                                                                        // 204
    });                                                                                                      // 204
    var dataAdherentes = Settings.findOne({                                                                  // 205
        clave: "importeAdherentes"                                                                           // 205
    });                                                                                                      // 205
    var dataActivos = Settings.findOne({                                                                     // 206
        clave: "importeActivos"                                                                              // 206
    });                                                                                                      // 206
    var edadAdherente = parseFloat(Settings.findOne({                                                        // 207
        clave: "edadAdherente"                                                                               // 207
    }).valor);                                                                                               // 207
    var socio = Socios.findOne({                                                                             // 209
        _id: idSocio                                                                                         // 209
    });                                                                                                      // 209
    var anos = getEdadSocio(socio.fechaNacimiento);                                                          // 210
    if (socio.esActivo) return dataActivos.valor;                                                            // 212
    if (anos < edadAdherente) return dataParticipantes.valor;                                                // 213
    return dataAdherentes.valor;                                                                             // 214
};                                                                                                           // 215
                                                                                                             //
getImporteSocioDatos = function (fechaNacimiento, esActivo) {                                                // 216
    var dataParticipantes = Settings.findOne({                                                               // 218
        clave: "importeParticipantes"                                                                        // 218
    });                                                                                                      // 218
    var dataAdherentes = Settings.findOne({                                                                  // 219
        clave: "importeAdherentes"                                                                           // 219
    });                                                                                                      // 219
    var dataActivos = Settings.findOne({                                                                     // 220
        clave: "importeActivos"                                                                              // 220
    });                                                                                                      // 220
    var edadAdherente = parseFloat(Settings.findOne({                                                        // 221
        clave: "edadAdherente"                                                                               // 221
    }).valor);                                                                                               // 221
    var anos = getEdadSocio(fechaNacimiento);                                                                // 224
    if (esActivo) return dataActivos.valor;                                                                  // 226
    if (anos < edadAdherente) return dataParticipantes.valor;                                                // 227
    return dataAdherentes.valor;                                                                             // 228
};                                                                                                           // 229
                                                                                                             //
module.exports = getTipoSocio;                                                                               // 231
///////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"server":{"main.js":["meteor/meteor",function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                           //
// server/main.js                                                                                            //
//                                                                                                           //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                             //
var Meteor = void 0;                                                                                         // 1
module.import('meteor/meteor', {                                                                             // 1
  "Meteor": function (v) {                                                                                   // 1
    Meteor = v;                                                                                              // 1
  }                                                                                                          // 1
}, 0);                                                                                                       // 1
                                                                                                             //
var getPromociones = function (principales) {                                                                // 3
  var sal = [];                                                                                              // 4
  var arr = Publicidades.find(filtro).fetch();                                                               // 7
                                                                                                             //
  for (var i = 0; i < arr.length; i++) {                                                                     // 8
    var aux = arr[i];                                                                                        // 9
    var comercio = Meteor.users.findOne({                                                                    // 10
      _id: aux.idUsuario                                                                                     // 10
    }).profile;                                                                                              // 10
    aux.logoEmpresa = comercio.logo;                                                                         // 11
    aux.domicilio = comercio.domicilio;                                                                      // 12
    aux.telefono = comercio.telefono;                                                                        // 13
    aux.email = comercio.email;                                                                              // 14
    sal.push(aux);                                                                                           // 16
  }                                                                                                          // 17
                                                                                                             //
  return sal;                                                                                                // 18
};                                                                                                           // 20
                                                                                                             //
Meteor.methods({                                                                                             // 21
  "publicidades.cambiaCampo": function (id, campo, valor) {                                                  // 22
    var data = {};                                                                                           // 24
    data[campo] = valor;                                                                                     // 26
    console.log(data);                                                                                       // 27
    return Publicidades.update({                                                                             // 28
      _id: id                                                                                                // 28
    }, {                                                                                                     // 28
      $set: data                                                                                             // 28
    });                                                                                                      // 28
  },                                                                                                         // 29
  'users.cargarInicial': function (data) {                                                                   // 30
    var hayUsuarios = Meteor.users.find().count() > 0;                                                       // 31
                                                                                                             //
    if (!hayUsuarios) {                                                                                      // 32
      var perfil = {                                                                                         // 33
        nombres: "alejandro",                                                                                // 33
        rol: "administrador"                                                                                 // 33
      };                                                                                                     // 33
      Accounts.createUser({                                                                                  // 35
        username: "admin",                                                                                   // 35
        password: "admin",                                                                                   // 35
        profile: perfil                                                                                      // 35
      });                                                                                                    // 35
    }                                                                                                        // 36
  },                                                                                                         // 37
  "users.perfil": function (id) {                                                                            // 38
    return Meteor.users.findOne({                                                                            // 40
      _id: id                                                                                                // 40
    }).profile;                                                                                              // 40
  },                                                                                                         // 41
  "publicidades.subirVideo": function (video64, id) {                                                        // 42
    var fs = Npm.require('fs');                                                                              // 44
                                                                                                             //
    console.log(id);                                                                                         // 45
    Future = Npm.require('fibers/future');                                                                   // 46
    var fut1 = new Future();                                                                                 // 47
    var path = process.cwd() + '/../web.browser/app/images/' + id;                                           // 48
    fs.writeFile(path, video64, function (err, res) {                                                        // 49
      if (err) throw err;                                                                                    // 51
      console.log('Done!');                                                                                  // 52
      fut1.return(res);                                                                                      // 53
    });                                                                                                      // 54
    return fut1.wait();                                                                                      // 56
  },                                                                                                         // 57
  "publicidades.quitarPromo": function (idPromo, id) {                                                       // 58
    console.log(idPromo, id);                                                                                // 59
    return Publicidades.update({                                                                             // 60
      _id: id                                                                                                // 61
    }, {                                                                                                     // 61
      $pull: {                                                                                               // 62
        "promociones": {                                                                                     // 62
          "_id": idPromo                                                                                     // 62
        }                                                                                                    // 62
      }                                                                                                      // 62
    }, {                                                                                                     // 62
      getAutoValues: false                                                                                   // 63
    } // SIN ESTE PARAMETRO NO QUITA!!                                                                       // 63
    );                                                                                                       // 60
  },                                                                                                         // 65
  'users.list': function (data) {                                                                            // 66
    return Meteor.users.find().fetch();                                                                      // 67
  },                                                                                                         // 68
  'publicidades.all': function () {                                                                          // 69
    return Publicidades.find({});                                                                            // 70
  },                                                                                                         // 71
  'publicidades.promociones': function (principales) {                                                       // 72
    var ordenar = {                                                                                          // 73
      $sort: {                                                                                               // 74
        _id: 1                                                                                               // 75
      }                                                                                                      // 74
    };                                                                                                       // 73
    var filtro = {                                                                                           // 78
      estado: "ACTIVO"                                                                                       // 78
    };                                                                                                       // 78
    if (principales) filtro.muestraSlide = true;                                                             // 79
    var unw = {                                                                                              // 80
      $unwind: "$promociones"                                                                                // 80
    };                                                                                                       // 80
    var match = {                                                                                            // 81
      $match: filtro                                                                                         // 81
    };                                                                                                       // 81
    var proyecto = {                                                                                         // 83
      $project: {                                                                                            // 84
        _id: "$_id",                                                                                         // 85
        idUsuario: "$idUsuario",                                                                             // 86
        detalle: "$detalle",                                                                                 // 87
        estado: "$estado",                                                                                   // 88
        logo: "$logo",                                                                                       // 89
        detallePromocion: "$detalle",                                                                        // 90
        cantidad: "$cantidadDescuento",                                                                      // 91
        muestraSlide: "$muestraSlide",                                                                       // 92
        ahorroEn: "$tipoDescuento",                                                                          // 93
        detalleSlide: "$detalleSlide",                                                                       // 94
        videoYoutube: "$videoYoutube"                                                                        // 95
      }                                                                                                      // 84
    };                                                                                                       // 83
    var look = {                                                                                             // 100
      $lookup: {                                                                                             // 101
        from: "users",                                                                                       // 103
        localField: "idUsuario",                                                                             // 104
        foreignField: "_id",                                                                                 // 105
        as: "usuario"                                                                                        // 106
      }                                                                                                      // 102
    };                                                                                                       // 100
    var pipeline = [proyecto, match, look]; //if(grupo)pipeline.push(grupo)                                  // 109
                                                                                                             //
    var res = Publicidades.aggregate(pipeline);                                                              // 112
    return res;                                                                                              // 114
  },                                                                                                         // 115
  'users.one': function (id) {                                                                               // 116
    return Meteor.users.findOne({                                                                            // 117
      _id: id                                                                                                // 117
    });                                                                                                      // 117
  },                                                                                                         // 118
  'users.add': function (usuario, clave, perfil) {                                                           // 119
    return Accounts.createUser({                                                                             // 120
      username: usuario,                                                                                     // 120
      password: clave,                                                                                       // 120
      profile: perfil                                                                                        // 120
    });                                                                                                      // 120
  },                                                                                                         // 121
  'users.update': function (_id, usuario, perfil) {                                                          // 122
    return Meteor.users.update({                                                                             // 123
      _id: _id                                                                                               // 123
    }, {                                                                                                     // 123
      $set: {                                                                                                // 123
        profile: perfil,                                                                                     // 123
        username: usuario                                                                                    // 123
      }                                                                                                      // 123
    });                                                                                                      // 123
  },                                                                                                         // 124
  'users.remove': function (_id) {                                                                           // 125
    return Meteor.users.remove({                                                                             // 126
      _id: _id                                                                                               // 126
    });                                                                                                      // 126
  },                                                                                                         // 127
  'users.resetPassword': function (_id, clave) {                                                             // 128
    return Accounts.setPassword(_id, clave);                                                                 // 129
  },                                                                                                         // 130
  'settings.generarVariables': function () {                                                                 // 131
    if (!Settings.findOne({                                                                                  // 132
      clave: "hostInyeccion"                                                                                 // 132
    })) Settings.insert({                                                                                    // 132
      clave: "hostInyeccion",                                                                                // 132
      valor: "192.155.543.5"                                                                                 // 132
    });                                                                                                      // 132
    if (!Settings.findOne({                                                                                  // 133
      clave: "usuarioInyeccion"                                                                              // 133
    })) Settings.insert({                                                                                    // 133
      clave: "usuarioInyeccion",                                                                             // 133
      valor: "root"                                                                                          // 133
    });                                                                                                      // 133
    if (!Settings.findOne({                                                                                  // 134
      clave: "claveInyeccion"                                                                                // 134
    })) Settings.insert({                                                                                    // 134
      clave: "claveInyeccion",                                                                               // 134
      valor: "vertrigo"                                                                                      // 134
    });                                                                                                      // 134
    if (!Settings.findOne({                                                                                  // 135
      clave: "dbInyeccion"                                                                                   // 135
    })) Settings.insert({                                                                                    // 135
      clave: "dbInyeccion",                                                                                  // 135
      valor: "asociacion"                                                                                    // 135
    });                                                                                                      // 135
    if (!Settings.findOne({                                                                                  // 136
      clave: "proxNroLiquidacion"                                                                            // 136
    })) Settings.insert({                                                                                    // 136
      clave: "proxNroLiquidacion",                                                                           // 136
      valor: "1"                                                                                             // 136
    });                                                                                                      // 136
  },                                                                                                         // 137
  'settings.remove': function (id) {                                                                         // 138
    return Settings.remove({                                                                                 // 139
      _id: id                                                                                                // 139
    });                                                                                                      // 139
  },                                                                                                         // 140
  "settings.autoincrementaNroLiquidacion": function () {                                                     // 141
    console.log("fdd");                                                                                      // 142
    var nuevoValor = Number(Settings.findOne({                                                               // 143
      clave: "proxNroLiquidacion"                                                                            // 143
    }).valor) + 1;                                                                                           // 143
    Settings.update({                                                                                        // 144
      clave: "proxNroLiquidacion"                                                                            // 144
    }, {                                                                                                     // 144
      $set: {                                                                                                // 144
        valor: nuevoValor                                                                                    // 144
      }                                                                                                      // 144
    });                                                                                                      // 144
    console.log("cambio");                                                                                   // 145
  },                                                                                                         // 146
  "remote.syncLiquidacion": function (data) {                                                                // 147
    var Future = Npm.require('fibers/future');                                                               // 149
                                                                                                             //
    var fut1 = new Future();                                                                                 // 150
                                                                                                             //
    var exec = Npm.require("child_process").exec;                                                            // 151
                                                                                                             //
    var path = process.cwd() + '/../web.browser/app/shellPython/syncLiquidacion.py';                         // 152
    var command = "python " + path + " " + data._id;                                                         // 154
    exec(command, function (error, stdout, stderr) {                                                         // 156
      fut1.return(stderr);                                                                                   // 158
    });                                                                                                      // 159
    return fut1.wait();                                                                                      // 160
    return fut1.wait();                                                                                      // 162
  },                                                                                                         // 163
  "remote.syncOs": function () {                                                                             // 164
    Future = Npm.require('fibers/future');                                                                   // 166
    var fut1 = new Future();                                                                                 // 167
                                                                                                             //
    var exec = Npm.require("child_process").exec;                                                            // 168
                                                                                                             //
    var path = process.cwd() + '/../web.browser/app/shellPython/importarOs.py';                              // 170
    var command = "python " + path;                                                                          // 172
    exec(command, function (error, stdout, stderr) {                                                         // 173
      if (error) {                                                                                           // 174
        console.log(error);                                                                                  // 175
        throw new Meteor.Error(500, command + " failed");                                                    // 176
      }                                                                                                      // 177
                                                                                                             //
      console.log(stdout);                                                                                   // 178
      fut1.return(stdout.toString());                                                                        // 179
    });                                                                                                      // 180
    return fut1.wait();                                                                                      // 181
    return fut1.wait();                                                                                      // 183
  },                                                                                                         // 184
  'liquidaciones.one': function (id) {                                                                       // 185
    return Liquidaciones.findOne({                                                                           // 187
      _id: id                                                                                                // 187
    });                                                                                                      // 187
  },                                                                                                         // 188
  'liquidaciones.remove': function (id) {                                                                    // 189
    return Liquidaciones.remove({                                                                            // 191
      _id: id                                                                                                // 191
    });                                                                                                      // 191
  },                                                                                                         // 192
  "liquidaciones.updateFactura": function (data, res) {                                                      // 193
    console.log(data);                                                                                       // 194
    console.log(res);                                                                                        // 195
    return true;                                                                                             // 196
  },                                                                                                         // 197
  'liquidaciones_factura.remove': function (idLiquidacion, id) {                                             // 198
    return Liquidaciones.update({                                                                            // 199
      _id: idLiquidacion                                                                                     // 200
    }, {                                                                                                     // 200
      $pull: {                                                                                               // 201
        "facturas": {                                                                                        // 201
          "_id": id                                                                                          // 201
        }                                                                                                    // 201
      }                                                                                                      // 201
    }, {                                                                                                     // 201
      getAutoValues: false                                                                                   // 202
    } // SIN ESTE PARAMETRO NO QUITA!!                                                                       // 202
    );                                                                                                       // 199
  }                                                                                                          // 204
});                                                                                                          // 21
                                                                                                             //
if (Meteor.isServer) {                                                                                       // 207
  Meteor.publish('liquidaciones.all', function (usuario) {                                                   // 209
    if (usuario) {                                                                                           // 211
      if (usuario.profile.rol === "secretaria") return Liquidaciones.find({                                  // 212
        idUsuario: usuario._id                                                                               // 212
      });                                                                                                    // 212
      return Liquidaciones.find();                                                                           // 213
    }                                                                                                        // 214
                                                                                                             //
    return [];                                                                                               // 215
  });                                                                                                        // 217
  Meteor.publish('publicidades.all', function () {                                                           // 218
    return Publicidades.find();                                                                              // 219
  });                                                                                                        // 220
  Meteor.publish('nomencladores.one', function (idNomenclador) {                                             // 221
    var res = Nomencladores.find({                                                                           // 222
      _id: Number(idNomenclador)                                                                             // 222
    });                                                                                                      // 222
    return res;                                                                                              // 223
  });                                                                                                        // 224
  Meteor.publish('settings.all', function () {                                                               // 225
    return Settings.find();                                                                                  // 226
  });                                                                                                        // 227
}                                                                                                            // 228
///////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]}},{"extensions":[".js",".json"]});
require("./lib/collections.js");
require("./lib/router.js");
require("./lib/utils.js");
require("./server/main.js");
//# sourceMappingURL=app.js.map
