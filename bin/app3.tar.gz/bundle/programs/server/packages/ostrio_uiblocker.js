(function () {



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['ostrio:uiblocker'] = {};

})();
