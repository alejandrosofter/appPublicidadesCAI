var require = meteorInstall({"lib":{"collections.js":function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                           //
// lib/collections.js                                                                                        //
//                                                                                                           //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                             //
Settings = new Mongo.Collection('settings');                                                                 // 1
Publicidades = new Mongo.Collection('publicidades');                                                         // 2
Socios = new Mongo.Collection('socios');                                                                     // 3
Settings.attachSchema(new SimpleSchema({                                                                     // 5
  _id: {                                                                                                     // 6
    type: String,                                                                                            // 7
    label: "ID"                                                                                              // 8
  },                                                                                                         // 6
  clave: {                                                                                                   // 10
    type: String,                                                                                            // 11
    optional: false,                                                                                         // 12
    label: 'Clave'                                                                                           // 13
  },                                                                                                         // 10
  valor: {                                                                                                   // 15
    type: String,                                                                                            // 16
    label: 'Valor'                                                                                           // 17
  }                                                                                                          // 15
}));                                                                                                         // 5
Socios.attachSchema(new SimpleSchema({                                                                       // 20
  _id: {                                                                                                     // 21
    type: String,                                                                                            // 22
    label: "ID"                                                                                              // 23
  },                                                                                                         // 21
  nombreSocio: {                                                                                             // 25
    type: String,                                                                                            // 26
    optional: false,                                                                                         // 27
    label: 'Nombres'                                                                                         // 28
  },                                                                                                         // 25
  nroSocio: {                                                                                                // 30
    type: String,                                                                                            // 31
    label: 'Nro Socio'                                                                                       // 32
  },                                                                                                         // 30
  estado: {                                                                                                  // 34
    type: String,                                                                                            // 35
    label: 'Estado'                                                                                          // 36
  },                                                                                                         // 34
  alDia: {                                                                                                   // 38
    type: Boolean,                                                                                           // 39
    label: 'Esta al dia?'                                                                                    // 40
  }                                                                                                          // 38
}));                                                                                                         // 20
Publicidades.attachSchema(new SimpleSchema({                                                                 // 44
  idUsuario: {                                                                                               // 45
    type: String,                                                                                            // 46
    label: "Comercio",                                                                                       // 47
    optional: true,                                                                                          // 48
    autoform: {                                                                                              // 49
      type: "select2",                                                                                       // 51
      select2Options: {                                                                                      // 53
        placeholder: 'Comercio...',                                                                          // 54
        width: "400px",                                                                                      // 55
        allowClear: true                                                                                     // 56
      }                                                                                                      // 53
    }                                                                                                        // 49
  },                                                                                                         // 45
  fecha: {                                                                                                   // 60
    type: Date,                                                                                              // 61
    autoform: {                                                                                              // 62
      style: "width:160px",                                                                                  // 63
      defaultValue: new Date()                                                                               // 64
    },                                                                                                       // 62
    optional: false,                                                                                         // 66
    label: 'Fecha'                                                                                           // 67
  },                                                                                                         // 60
  detalle: {                                                                                                 // 69
    type: String,                                                                                            // 70
    label: 'Detalle'                                                                                         // 71
  },                                                                                                         // 69
  imagenBanner: {                                                                                            // 73
    type: String,                                                                                            // 74
    label: 'Imagen Banner',                                                                                  // 75
    optional: true                                                                                           // 76
  },                                                                                                         // 73
  textoContrato: {                                                                                           // 78
    type: String,                                                                                            // 79
    label: 'Texto Contrato',                                                                                 // 80
    optional: true,                                                                                          // 81
    optional: true                                                                                           // 82
  },                                                                                                         // 78
  tipoDescuento: {                                                                                           // 84
    type: String,                                                                                            // 85
    label: 'Tipo descuento',                                                                                 // 86
    optional: true                                                                                           // 87
  },                                                                                                         // 84
  cantidadDescuento: {                                                                                       // 89
    type: String,                                                                                            // 90
    label: 'Cant. descuento'                                                                                 // 91
  },                                                                                                         // 89
  detalleSlide: {                                                                                            // 93
    type: String,                                                                                            // 94
    label: 'Detalle Slide',                                                                                  // 95
    optional: true                                                                                           // 96
  },                                                                                                         // 93
  link: {                                                                                                    // 98
    type: String,                                                                                            // 99
    label: 'Link Banner',                                                                                    // 100
    optional: true                                                                                           // 101
  },                                                                                                         // 98
  muestraSlide: {                                                                                            // 103
    type: Boolean,                                                                                           // 104
    label: 'Muestra en Slide',                                                                               // 105
    optional: true                                                                                           // 106
  },                                                                                                         // 103
  logo: {                                                                                                    // 108
    type: String,                                                                                            // 109
    label: 'Logo',                                                                                           // 110
    optional: true                                                                                           // 111
  },                                                                                                         // 108
  videoYoutube: {                                                                                            // 113
    type: String,                                                                                            // 114
    label: 'Video YOUTBE',                                                                                   // 115
    optional: true                                                                                           // 116
  },                                                                                                         // 113
  tieneVideo: {                                                                                              // 118
    type: Boolean,                                                                                           // 119
    label: 'Tiene Video',                                                                                    // 120
    optional: true                                                                                           // 121
  },                                                                                                         // 118
  estado: {                                                                                                  // 123
    type: String,                                                                                            // 124
    optional: true,                                                                                          // 125
    label: "Estado",                                                                                         // 126
    autoform: {                                                                                              // 128
      defaultValue: "PENDIENTE",                                                                             // 129
      type: "select-radio-inline",                                                                           // 130
      trueLabel: "Yes",                                                                                      // 131
      falseLabel: "No",                                                                                      // 131
      options: [{                                                                                            // 132
        label: "ACTIVO",                                                                                     // 133
        value: "ACTIVO"                                                                                      // 133
      }, {                                                                                                   // 133
        label: "INACTIVO",                                                                                   // 134
        value: "INACTIVO"                                                                                    // 134
      }]                                                                                                     // 134
    }                                                                                                        // 128
  },                                                                                                         // 123
  usoSocios: {                                                                                               // 139
    type: Array,                                                                                             // 140
    optional: true,                                                                                          // 141
    label: "Uso Socios"                                                                                      // 142
  },                                                                                                         // 139
  "usoSocios.$": {                                                                                           // 145
    type: Object                                                                                             // 146
  },                                                                                                         // 145
  "usoSocios.$._id": {                                                                                       // 148
    type: String,                                                                                            // 150
    autoValue: function () {                                                                                 // 151
      return Meteor.uuid();                                                                                  // 152
    }                                                                                                        // 153
  },                                                                                                         // 148
  "usoSocios.$.fecha": {                                                                                     // 156
    type: Date,                                                                                              // 157
    optional: false,                                                                                         // 158
    label: "Fecha"                                                                                           // 159
  },                                                                                                         // 156
  "usoSocios.$.idSocio": {                                                                                   // 161
    type: String,                                                                                            // 162
    optional: true,                                                                                          // 163
    label: "Socio"                                                                                           // 164
  },                                                                                                         // 161
  "usoSocios.$.idPromocion": {                                                                               // 166
    type: String,                                                                                            // 167
    optional: true,                                                                                          // 168
    label: "Promocion"                                                                                       // 169
  },                                                                                                         // 166
  promociones: {                                                                                             // 171
    type: Array,                                                                                             // 172
    optional: true,                                                                                          // 173
    label: "Promociones"                                                                                     // 174
  },                                                                                                         // 171
  "promociones.$": {                                                                                         // 177
    type: Object                                                                                             // 178
  },                                                                                                         // 177
  "promociones.$._id": {                                                                                     // 180
    type: String,                                                                                            // 182
    autoValue: function () {                                                                                 // 183
      return Meteor.uuid();                                                                                  // 184
    }                                                                                                        // 185
  },                                                                                                         // 180
  //  "promociones.$.fechaHasta": {                                                                          // 189
  //   type: Date,                                                                                           // 190
  //   label:"Fecha Hasta"                                                                                   // 192
  // },                                                                                                      // 193
  "promociones.$.detalle": {                                                                                 // 194
    type: String,                                                                                            // 195
    optional: false,                                                                                         // 196
    label: "Detalle"                                                                                         // 197
  },                                                                                                         // 194
  "promociones.$.ahorroEn": {                                                                                // 199
    type: String,                                                                                            // 200
    optional: false,                                                                                         // 201
    label: "Ahorro En..."                                                                                    // 202
  },                                                                                                         // 199
  "promociones.$.cantidad": {                                                                                // 204
    type: String,                                                                                            // 205
    optional: false,                                                                                         // 206
    label: "Cantidad"                                                                                        // 207
  },                                                                                                         // 204
  "promociones.$.logo": {                                                                                    // 209
    type: String,                                                                                            // 210
    optional: true,                                                                                          // 211
    label: "Logo"                                                                                            // 212
  },                                                                                                         // 209
  "promociones.$.cantidaCuotas": {                                                                           // 214
    type: String,                                                                                            // 215
    optional: true,                                                                                          // 216
    label: "Cant. Cuotas"                                                                                    // 217
  },                                                                                                         // 214
  "promociones.$.cantidadCuotas": {                                                                          // 219
    type: String,                                                                                            // 220
    optional: true,                                                                                          // 221
    label: "Cant. Cuotas"                                                                                    // 222
  }                                                                                                          // 219
}, {                                                                                                         // 44
  tracker: Tracker                                                                                           // 227
}));                                                                                                         // 227
///////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"router.js":function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                           //
// lib/router.js                                                                                             //
//                                                                                                           //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                             //
applicationController = RouteController.extend({                                                             // 1
	layoutTemplate: 'layoutApp',                                                                                // 2
	loadingTemplate: 'loaderGral',                                                                              // 3
	notFoundTemlplate: 'notFound',                                                                              // 4
	waitOn: function () {                                                                                       // 6
		return [Meteor.subscribe("publicidades.all")];                                                             // 7
	},                                                                                                          // 10
	onBeforeAction: function (pause) {                                                                          // 11
		this.render('loaderGral');                                                                                 // 12
		this.next();                                                                                               // 13
	},                                                                                                          // 14
	action: function () {                                                                                       // 15
		if (!this.ready()) {                                                                                       // 16
			this.render('loaderGral');                                                                                // 17
		} else {                                                                                                   // 18
			this.render();                                                                                            // 20
		}                                                                                                          // 22
	}                                                                                                           // 23
});                                                                                                          // 1
applicationControllerInicio = RouteController.extend({                                                       // 25
	layoutTemplate: 'layoutSolo',                                                                               // 26
	loadingTemplate: 'loaderGral',                                                                              // 27
	notFoundTemlplate: 'notFound',                                                                              // 28
	waitOn: function () {                                                                                       // 30
		return [];                                                                                                 // 31
	},                                                                                                          // 33
	onBeforeAction: function (pause) {                                                                          // 34
		this.render('loaderGral');                                                                                 // 35
		this.next();                                                                                               // 36
	},                                                                                                          // 37
	action: function () {                                                                                       // 38
		if (!this.ready()) {                                                                                       // 39
			this.render('loaderGral');                                                                                // 40
		} else {                                                                                                   // 41
			this.render();                                                                                            // 43
		}                                                                                                          // 45
	}                                                                                                           // 46
});                                                                                                          // 25
Router.route('/', {                                                                                          // 49
	path: '/',                                                                                                  // 50
	// layoutTemplate: 'layoutVacio',                                                                           // 51
	template: "publicidades",                                                                                   // 52
	controller: applicationController                                                                           // 53
});                                                                                                          // 49
Router.route('/inicio', {                                                                                    // 55
	path: '/inicio',                                                                                            // 56
	// layoutTemplate: 'layoutVacio',                                                                           // 57
	template: "publicidades",                                                                                   // 58
	controller: applicationController                                                                           // 59
});                                                                                                          // 55
Router.route('settings', {                                                                                   // 62
	path: '/settings',                                                                                          // 63
	template: "settings",                                                                                       // 64
	controller: applicationController                                                                           // 65
});                                                                                                          // 62
Router.route('usuarios', {                                                                                   // 67
	path: '/usuarios',                                                                                          // 68
	template: "usuarios",                                                                                       // 69
	controller: applicationController                                                                           // 70
});                                                                                                          // 67
Router.route('publicidades', {                                                                               // 72
	path: '/publicidades',                                                                                      // 73
	template: "publicidades",                                                                                   // 74
	controller: applicationController                                                                           // 75
});                                                                                                          // 72
Router.route('/editarBanner/:_id', {                                                                         // 77
	controller: applicationController,                                                                          // 78
	template: 'editarBanner',                                                                                   // 79
	data: function () {                                                                                         // 80
		var sal = Publicidades.findOne({                                                                           // 81
			_id: this.params._id                                                                                      // 81
		});                                                                                                        // 81
		return sal;                                                                                                // 82
	}                                                                                                           // 83
});                                                                                                          // 77
Router.route('/liquidaciones_facturas/:_id', {                                                               // 85
	controller: applicationController,                                                                          // 86
	template: 'liquidaciones_facturas',                                                                         // 87
	data: function () {                                                                                         // 88
		var sal = Liquidaciones.findOne({                                                                          // 89
			_id: this.params._id                                                                                      // 89
		});                                                                                                        // 89
		console.log(this.params);                                                                                  // 90
		return sal;                                                                                                // 91
	}                                                                                                           // 92
});                                                                                                          // 85
Router.route('/nomencladores/:_id', {                                                                        // 94
	controller: applicationController,                                                                          // 95
	template: 'nomencladores',                                                                                  // 96
	data: function () {                                                                                         // 97
		Meteor.subscribe('nomencladores.all');                                                                     // 98
		var sal = Nomencladores.findOne({                                                                          // 99
			_id: this.params._id                                                                                      // 99
		});                                                                                                        // 99
		return sal;                                                                                                // 100
	}                                                                                                           // 101
});                                                                                                          // 94
///////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"utils.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                           //
// lib/utils.js                                                                                              //
//                                                                                                           //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                             //
/*eslint-disable no-unreachable, no-extend-native, no-undef, semi*/function getMedidas(srcWidth, srcHeight, maxWidth, maxHeight) {
    var ratio = [maxWidth / srcWidth, maxHeight / srcHeight];                                                // 4
    ratio = Math.min(ratio[0], ratio[1]);                                                                    // 5
    return {                                                                                                 // 7
        width: srcWidth * ratio,                                                                             // 7
        height: srcHeight * ratio                                                                            // 7
    };                                                                                                       // 7
}                                                                                                            // 8
                                                                                                             //
String.prototype.resizeImage = function (w, h, callback) {                                                   // 10
    var data = this;                                                                                         // 11
    var canvas = document.getElementById('canvas');                                                          // 12
    var context = canvas.getContext("2d");                                                                   // 13
    context.clearRect(0, 0, canvas.width, canvas.height);                                                    // 14
    var img = new Image();                                                                                   // 15
                                                                                                             //
    img.onload = function () {                                                                               // 16
        var medidas = getMedidas(img.width, img.height, w, h);                                               // 17
        context.drawImage(img, 0, 0, medidas.width, medidas.height);                                         // 18
        var dataurl = canvas.toDataURL();                                                                    // 19
        if (callback) callback(dataurl);                                                                     // 20
    };                                                                                                       // 21
                                                                                                             //
    img.src = data;                                                                                          // 22
};                                                                                                           // 23
                                                                                                             //
String.prototype.lpad = function (padString, length) {                                                       // 24
    var str = this;                                                                                          // 25
                                                                                                             //
    while (str.length < length) {                                                                            // 26
        str = padString + str;                                                                               // 27
    }                                                                                                        // 26
                                                                                                             //
    return str;                                                                                              // 28
};                                                                                                           // 29
                                                                                                             //
Date.prototype.addHours = function (h) {                                                                     // 30
    this.setTime(this.getTime() + h * 60 * 60 * 1000);                                                       // 31
    return this;                                                                                             // 32
};                                                                                                           // 33
                                                                                                             //
Date.prototype.addDays = function (num) {                                                                    // 34
    var value = this.valueOf();                                                                              // 35
    value += 86400000 * num;                                                                                 // 36
    return new Date(value);                                                                                  // 37
};                                                                                                           // 38
                                                                                                             //
String.prototype.lpad = function (padString, length) {                                                       // 39
    var str = this;                                                                                          // 40
                                                                                                             //
    while (str.length < length) {                                                                            // 41
        str = padString + str;                                                                               // 42
    }                                                                                                        // 41
                                                                                                             //
    return str;                                                                                              // 43
};                                                                                                           // 44
                                                                                                             //
String.prototype.capitalizar = function () {                                                                 // 45
    return this.charAt(0).toUpperCase() + this.slice(1);                                                     // 46
};                                                                                                           // 47
                                                                                                             //
String.prototype.rpad = function (padString, length) {                                                       // 48
    var str = this;                                                                                          // 49
                                                                                                             //
    while (str.length < length) {                                                                            // 50
        str = str + padString;                                                                               // 51
    }                                                                                                        // 50
                                                                                                             //
    return str;                                                                                              // 52
};                                                                                                           // 53
                                                                                                             //
Date.prototype.getFecha = function () {                                                                      // 54
    var value = this.valueOf();                                                                              // 55
    value += 86400000 * 1;                                                                                   // 56
    var d = new Date(value);                                                                                 // 57
    return d.getDate() + "/" + (d.getMonth() + 1) + "/" + d.getFullYear();                                   // 58
};                                                                                                           // 59
                                                                                                             //
Date.prototype.getFecha2 = function () {                                                                     // 60
    var value = this.valueOf();                                                                              // 61
    value += 86400000 * 1;                                                                                   // 62
    var d = new Date(value);                                                                                 // 63
    return d.getDate() + "/" + (d.getMonth() + 1) + "/" + d.getFullYear();                                   // 64
};                                                                                                           // 65
                                                                                                             //
Date.prototype.getMes = function () {                                                                        // 66
    var value = this.valueOf();                                                                              // 67
    value += 86400000 * 1;                                                                                   // 68
    var d = new Date(value);                                                                                 // 69
    return d.getMonth() + 1;                                                                                 // 70
};                                                                                                           // 71
                                                                                                             //
Date.prototype.getDia = function () {                                                                        // 72
    var value = this.valueOf();                                                                              // 73
    value += 86400000 * 1;                                                                                   // 74
    var d = new Date(value);                                                                                 // 75
    return d.getDate();                                                                                      // 76
};                                                                                                           // 77
                                                                                                             //
Date.prototype.getMesLetras = function () {                                                                  // 78
    var value = this.valueOf();                                                                              // 79
    var d = new Date(value);                                                                                 // 80
    var meses = ["ENERO", "FEBRERO", "MARZO", "ABRIL", "MAYO", "JUNIO", "JULIO", "AGOSTO", "SEPTEMBRE", "OCTUBRE", "NOVIEMBRE", "DICIEMBRE"];
    return meses[d.getMonth()];                                                                              // 83
};                                                                                                           // 84
                                                                                                             //
Date.prototype.getAno = function () {                                                                        // 85
    var value = this.valueOf();                                                                              // 86
    value += 86400000 * 1;                                                                                   // 87
    var d = new Date(value);                                                                                 // 88
    return d.getFullYear();                                                                                  // 89
};                                                                                                           // 90
                                                                                                             //
Number.prototype.formatMoney = function (n, x, s, c) {                                                       // 91
    var re = '\\d(?=(\\d{' + (x || 3) + '})+' + (n > 0 ? '\\D' : '$') + ')',                                 // 92
        num = this.toFixed(Math.max(0, ~~n));                                                                // 92
    return (c ? num.replace('.', c) : num).replace(new RegExp(re, 'g'), '$&' + (s || ','));                  // 95
};                                                                                                           // 96
                                                                                                             //
function validarLargoCBU(cbu) {                                                                              // 97
    if (cbu.length != 22) {                                                                                  // 98
        return false;                                                                                        // 98
    }                                                                                                        // 98
                                                                                                             //
    return true;                                                                                             // 99
}                                                                                                            // 100
                                                                                                             //
var validarCodigoBanco = function (codigo) {                                                                 // 102
    if (codigo.length != 8) {                                                                                // 103
        return false;                                                                                        // 103
    }                                                                                                        // 103
                                                                                                             //
    var banco = codigo.substr(0, 3);                                                                         // 104
    var digitoVerificador1 = codigo[3];                                                                      // 105
    var sucursal = codigo.substr(4, 3);                                                                      // 106
    var digitoVerificador2 = codigo[7];                                                                      // 107
    var suma = banco[0] * 7 + banco[1] * 1 + banco[2] * 3 + digitoVerificador1 * 9 + sucursal[0] * 7 + sucursal[1] * 1 + sucursal[2] * 3;
    var diferencia = 10 - suma % 10;                                                                         // 111
    return diferencia == digitoVerificador2;                                                                 // 113
};                                                                                                           // 114
                                                                                                             //
mesLetras = function (mes) {                                                                                 // 115
    if (mes == 1) return "ENERO";                                                                            // 117
    if (mes == 2) return "FEBRERO";                                                                          // 118
    if (mes == 3) return "MARZO";                                                                            // 119
    if (mes == 4) return "ABRIL";                                                                            // 120
    if (mes == 5) return "MAYO";                                                                             // 121
    if (mes == 6) return "JUNIO";                                                                            // 122
    if (mes == 7) return "JULIO";                                                                            // 123
    if (mes == 8) return "AGOSTO";                                                                           // 124
    if (mes == 9) return "SEPTEMBRE";                                                                        // 125
    if (mes == 10) return "OCTUBRE";                                                                         // 126
    if (mes == 11) return "NOVIEMBRE";                                                                       // 127
    if (mes == 12) return "DICIEMBRE";                                                                       // 128
    return "s/a";                                                                                            // 129
};                                                                                                           // 130
                                                                                                             //
mesNumeros = function (mes) {                                                                                // 131
    if (mes == "ENERO") return 1;                                                                            // 133
    if (mes == "FEBRERO") return 2;                                                                          // 134
    if (mes == "MARZO") return 3;                                                                            // 135
    if (mes == "ABRIL") return 4;                                                                            // 136
    if (mes == "MAYO") return 5;                                                                             // 137
    if (mes == "JUNIO") return 6;                                                                            // 138
    if (mes == "JULIO") return 7;                                                                            // 139
    if (mes == "AGOSTO") return 8;                                                                           // 140
    if (mes == "SEPTEMBRE") return 9;                                                                        // 141
    if (mes == "OCTUBRE") return 10;                                                                         // 142
    if (mes == "NOVIEMBRE") return 11;                                                                       // 143
    if (mes == "DICIEMBRE") return 12;                                                                       // 144
    return null;                                                                                             // 145
};                                                                                                           // 146
                                                                                                             //
getMeses = function () {                                                                                     // 147
    return ["ENERO", "FEBRERO", "MARZO", "ABRIL", "MAYO", "JUNIO", "JULIO", "AGOSTO", "SEPTEMBRE", "OCTUBRE", "NOVIEMBRE", "DICIEMBRE"];
};                                                                                                           // 150
                                                                                                             //
ripFechaArchivo = function (fechaDate) {                                                                     // 151
    var st = fechaDate.toLocaleDateString();                                                                 // 153
    var arr = st.split("/");                                                                                 // 154
    return arr[0].lpad("0", 2) + arr[1].lpad("0", 2) + arr[2].lpad("0", 2);                                  // 156
};                                                                                                           // 157
                                                                                                             //
getImporteTotalSocios = function (arr) {                                                                     // 158
    var sum = 0;                                                                                             // 160
                                                                                                             //
    for (var i = 0; i < arr.length; i++) {                                                                   // 161
        sum += arr[i].importe * 1;                                                                           // 161
    }                                                                                                        // 161
                                                                                                             //
    return sum;                                                                                              // 162
};                                                                                                           // 163
                                                                                                             //
ripImporteArchivo = function (importe) {                                                                     // 164
    importe = importe + "";                                                                                  // 166
    var arr = importe.split(".");                                                                            // 167
    if (arr.length > 1) return arr[0].lpad("0", 8) + arr[1].lpad("0", 2);                                    // 168
    return arr[0].lpad("0", 8) + "00";                                                                       // 169
};                                                                                                           // 170
                                                                                                             //
var validarCuenta = function (cuenta) {                                                                      // 171
    if (cuenta.length != 14) {                                                                               // 172
        return false;                                                                                        // 172
    }                                                                                                        // 172
                                                                                                             //
    var digitoVerificador = cuenta[13];                                                                      // 173
    var suma = cuenta[0] * 3 + cuenta[1] * 9 + cuenta[2] * 7 + cuenta[3] * 1 + cuenta[4] * 3 + cuenta[5] * 9 + cuenta[6] * 7 + cuenta[7] * 1 + cuenta[8] * 3 + cuenta[9] * 9 + cuenta[10] * 7 + cuenta[11] * 1 + cuenta[12] * 3;
    var diferencia = 10 - suma % 10;                                                                         // 175
    return diferencia == digitoVerificador;                                                                  // 176
};                                                                                                           // 177
                                                                                                             //
validarCBU = function (cbu) {                                                                                // 179
    return validarLargoCBU(cbu) && validarCodigoBanco(cbu.substr(0, 8)) && validarCuenta(cbu.substr(8, 14));
};                                                                                                           // 181
                                                                                                             //
getClaseTipoSocio = function (fechaNac, esActivo, estado) {                                                  // 182
    var tipo = getTipoSocio(fechaNac, esActivo);                                                             // 183
    if (estado == "BAJA") return "bajaSocio";                                                                // 184
    var clase = tipo === "PARTICIPANTE" ? "text-warning" : "text-info";                                      // 185
    if (tipo === "ACTIVO") clase = "text-danger";                                                            // 186
    return clase;                                                                                            // 187
};                                                                                                           // 188
                                                                                                             //
geTipoSocioEdad = function (edad, activo) {                                                                  // 189
    var edadAdherente = parseFloat(Settings.findOne({                                                        // 191
        clave: "edadAdherente"                                                                               // 191
    }).valor);                                                                                               // 191
    if (activo) return "ACTIVO";                                                                             // 192
    if (edad >= edadAdherente) return "ADHERENTE";                                                           // 193
    return "PARTICIPANTE";                                                                                   // 195
};                                                                                                           // 196
                                                                                                             //
getImporteSocioEdad = function (edad, activo) {                                                              // 197
    var edadAdherente = parseFloat(Settings.findOne({                                                        // 199
        clave: "edadAdherente"                                                                               // 199
    }).valor);                                                                                               // 199
    if (activo) return parseFloat(Settings.findOne({                                                         // 200
        clave: "importeActivos"                                                                              // 200
    }).valor);                                                                                               // 200
    if (edad >= edadAdherente) return parseFloat(Settings.findOne({                                          // 201
        clave: "imprteAdherentes"                                                                            // 201
    }).valor);                                                                                               // 201
    return parseFloat(Settings.findOne({                                                                     // 203
        clave: "importeParticipantes"                                                                        // 203
    }).valor);                                                                                               // 203
};                                                                                                           // 204
                                                                                                             //
getEdadSocio = function (fechaNac) {                                                                         // 205
    var hoy = new Date();                                                                                    // 206
    var cumpleanos = new Date(fechaNac);                                                                     // 207
    var edad = hoy.getAno() - cumpleanos.getAno();                                                           // 208
    var m = hoy.getMes() - cumpleanos.getMes();                                                              // 209
                                                                                                             //
    if (m < 0 || m === 0 && hoy.getDia() < cumpleanos.getDia()) {                                            // 211
        edad--;                                                                                              // 212
    }                                                                                                        // 213
                                                                                                             //
    return edad;                                                                                             // 215
};                                                                                                           // 216
                                                                                                             //
getTipoSocio = function (fechaNac, esActivo) {                                                               // 217
    var edadAdherente = parseFloat(Settings.findOne({                                                        // 218
        clave: "edadAdherente"                                                                               // 218
    }).valor);                                                                                               // 218
    var anos = getEdadSocio(fechaNac);                                                                       // 220
    if (esActivo) return "ACTIVO";                                                                           // 221
    return anos < edadAdherente ? "PARTICIPANTE" : "ADHERENTE";                                              // 222
};                                                                                                           // 223
                                                                                                             //
getImporteSocio = function (idSocio) {                                                                       // 224
    var dataParticipantes = Settings.findOne({                                                               // 226
        clave: "importeParticipantes"                                                                        // 226
    });                                                                                                      // 226
    var dataAdherentes = Settings.findOne({                                                                  // 227
        clave: "importeAdherentes"                                                                           // 227
    });                                                                                                      // 227
    var dataActivos = Settings.findOne({                                                                     // 228
        clave: "importeActivos"                                                                              // 228
    });                                                                                                      // 228
    var edadAdherente = parseFloat(Settings.findOne({                                                        // 229
        clave: "edadAdherente"                                                                               // 229
    }).valor);                                                                                               // 229
    var socio = Socios.findOne({                                                                             // 231
        _id: idSocio                                                                                         // 231
    });                                                                                                      // 231
    var anos = getEdadSocio(socio.fechaNacimiento);                                                          // 232
    if (socio.esActivo) return dataActivos.valor;                                                            // 234
    if (anos < edadAdherente) return dataParticipantes.valor;                                                // 235
    return dataAdherentes.valor;                                                                             // 236
};                                                                                                           // 237
                                                                                                             //
getImporteSocioDatos = function (fechaNacimiento, esActivo) {                                                // 238
    var dataParticipantes = Settings.findOne({                                                               // 240
        clave: "importeParticipantes"                                                                        // 240
    });                                                                                                      // 240
    var dataAdherentes = Settings.findOne({                                                                  // 241
        clave: "importeAdherentes"                                                                           // 241
    });                                                                                                      // 241
    var dataActivos = Settings.findOne({                                                                     // 242
        clave: "importeActivos"                                                                              // 242
    });                                                                                                      // 242
    var edadAdherente = parseFloat(Settings.findOne({                                                        // 243
        clave: "edadAdherente"                                                                               // 243
    }).valor);                                                                                               // 243
    var anos = getEdadSocio(fechaNacimiento);                                                                // 246
    if (esActivo) return dataActivos.valor;                                                                  // 248
    if (anos < edadAdherente) return dataParticipantes.valor;                                                // 249
    return dataAdherentes.valor;                                                                             // 250
};                                                                                                           // 251
                                                                                                             //
module.exports = getTipoSocio;                                                                               // 253
///////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"server":{"main.js":["meteor/meteor","twilio",function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                           //
// server/main.js                                                                                            //
//                                                                                                           //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                             //
var Meteor = void 0;                                                                                         // 1
module.importSync("meteor/meteor", {                                                                         // 1
  Meteor: function (v) {                                                                                     // 1
    Meteor = v;                                                                                              // 1
  }                                                                                                          // 1
}, 0);                                                                                                       // 1
                                                                                                             //
var fs = Npm.require('fs');                                                                                  // 3
                                                                                                             //
var Future = Npm.require('fibers/future');                                                                   // 4
                                                                                                             //
var getPromociones = function (principales) {                                                                // 5
  var sal = [];                                                                                              // 6
  var arr = Publicidades.find(filtro).fetch();                                                               // 9
                                                                                                             //
  for (var i = 0; i < arr.length; i++) {                                                                     // 10
    var aux = arr[i];                                                                                        // 11
    var comercio = Meteor.users.findOne({                                                                    // 12
      _id: aux.idUsuario                                                                                     // 12
    }).profile;                                                                                              // 12
    aux.logoEmpresa = comercio.logo;                                                                         // 13
    aux.domicilio = comercio.domicilio;                                                                      // 14
    aux.telefono = comercio.telefono;                                                                        // 15
    aux.email = comercio.email;                                                                              // 16
    sal.push(aux);                                                                                           // 18
  }                                                                                                          // 19
                                                                                                             //
  return sal;                                                                                                // 20
};                                                                                                           // 22
                                                                                                             //
Meteor.methods({                                                                                             // 23
  "getSvgBanner": function (id) {                                                                            // 25
    var fs = Npm.require('fs');                                                                              // 27
                                                                                                             //
    Future = Npm.require('fibers/future');                                                                   // 28
    var fut1 = new Future(); //Publicidades.update({_id:id},{$set:{logo:"",imagenBanner:""}})                // 29
                                                                                                             //
    var path = Settings.findOne({                                                                            // 31
      clave: "pathImagenes"                                                                                  // 31
    }).valor + "/banner_" + id + ".txt";                                                                     // 31
    var text = fs.readFileSync(path, 'utf8');                                                                // 32
    return text;                                                                                             // 34
  },                                                                                                         // 35
  "publicidades.remove": function (id) {                                                                     // 36
    return Publicidades.remove({                                                                             // 37
      _id: id                                                                                                // 37
    });                                                                                                      // 37
  },                                                                                                         // 38
  "publicidades.guardarBanner": function (id, data) {                                                        // 39
    var fs = Npm.require('fs');                                                                              // 41
                                                                                                             //
    Future = Npm.require('fibers/future');                                                                   // 42
    var fut1 = new Future(); //Publicidades.update({_id:id},{$set:{logo:"",imagenBanner:""}})                // 43
                                                                                                             //
    var path = Settings.findOne({                                                                            // 45
      clave: "pathImagenes"                                                                                  // 45
    }).valor + "/banner_" + id + ".txt";                                                                     // 45
                                                                                                             //
    if (data) {                                                                                              // 46
      //fs.unlinkSync(path)                                                                                  // 48
      fs.writeFile(path, data, 'binary', function (err) {                                                    // 49
        // Meteor.wrapAsync(function(err,res){                                                               // 51
        //   Publicidades.update({_id:id},{$set:{logo:"",imagenBanner:""}})                                  // 52
        // })                                                                                                // 53
        fut1.return(err);                                                                                    // 54
      });                                                                                                    // 55
    } // fs.writeFile(path, data,                                                                            // 56
    //     function (err,res) {                                                                              // 59
    //         if (err) throw err;                                                                           // 60
    //           console.log('Done!');                                                                       // 61
    //           fut1.return(res)                                                                            // 62
    //     }                                                                                                 // 63
    // );                                                                                                    // 64
                                                                                                             //
                                                                                                             //
    return fut1.wait();                                                                                      // 65
  },                                                                                                         // 66
  "publicidades.guardarImagen": function (id, data) {                                                        // 67
    //Publicidades.update({_id:id},{$set:{imagenBanner:data}})                                               // 70
    var fs = Npm.require('fs');                                                                              // 71
                                                                                                             //
    Future = Npm.require('fibers/future');                                                                   // 72
    var fut1 = new Future(); //Publicidades.update({_id:id},{$set:{logo:"",imagenBanner:""}})                // 73
                                                                                                             //
    var path = Settings.findOne({                                                                            // 75
      clave: "pathImagenes"                                                                                  // 75
    }).valor + "/banner_" + id + ".png";                                                                     // 75
                                                                                                             //
    if (data) {                                                                                              // 77
      Publicidades.update({                                                                                  // 78
        _id: id                                                                                              // 78
      }, {                                                                                                   // 78
        $set: {                                                                                              // 78
          logo: "",                                                                                          // 78
          imagenBanner: ""                                                                                   // 78
        }                                                                                                    // 78
      }); // var base64Data  =   data.replace(/^data:image\/png;base64,/, "");                               // 78
      // var base64Data  =   base64Data.replace(/^data:image\/jpeg;base64,/, "");                            // 80
                                                                                                             //
      var base64Data = data.split(",")[1];                                                                   // 81
      base64Data += base64Data.replace('+', ' ');                                                            // 82
      var binaryData = new Buffer(base64Data, 'base64').toString('binary');                                  // 83
      if (fs.existsSync(path)) fs.unlinkSync(path);                                                          // 85
      fs.writeFile(path, binaryData, 'binary', function (err) {                                              // 86
        // Meteor.wrapAsync(function(err,res){                                                               // 88
        //   Publicidades.update({_id:id},{$set:{logo:"",imagenBanner:""}})                                  // 89
        // })                                                                                                // 90
        fut1.return(err);                                                                                    // 91
      });                                                                                                    // 92
    } // fs.writeFile(path, data,                                                                            // 93
    //     function (err,res) {                                                                              // 96
    //         if (err) throw err;                                                                           // 97
    //           console.log('Done!');                                                                       // 98
    //           fut1.return(res)                                                                            // 99
    //     }                                                                                                 // 100
    // );                                                                                                    // 101
                                                                                                             //
                                                                                                             //
    return fut1.wait();                                                                                      // 102
  },                                                                                                         // 103
  "enviarMensaje": function (data) {                                                                         // 104
    var accountSid = 'AC1091ce1c8be5d4a72073398f8e8aefe4';                                                   // 106
    var authToken = 'b53bcfd9a7d538d8b773632f10882b1c';                                                      // 107
                                                                                                             //
    var client = require('twilio')(accountSid, authToken);                                                   // 108
                                                                                                             //
    client.messages.create({                                                                                 // 110
      from: 'whatsapp:+14155238886',                                                                         // 112
      body: 'Hi Joe! Thanks for placing an order with us. We’ll let you know once your order has been processed and delivered. Your order number is O12235234',
      to: 'whatsapp:+542975447771'                                                                           // 114
    }).then(function (message) {                                                                             // 111
      return console.log(message);                                                                           // 116
    });                                                                                                      // 116
  },                                                                                                         // 118
  "images.guardar": function (data, id) {                                                                    // 119
    //Publicidades.update({_id:id},{$set:{imagenBanner:data}})                                               // 122
    var fs = Npm.require('fs');                                                                              // 123
                                                                                                             //
    Future = Npm.require('fibers/future');                                                                   // 124
    var fut1 = new Future();                                                                                 // 125
    var path = Settings.findOne({                                                                            // 126
      clave: "pathImagenes"                                                                                  // 126
    }).valor + "/" + id + ".png";                                                                            // 126
    var base64Data = data.replace(/^data:image\/png;base64,/, "");                                           // 127
    base64Data += base64Data.replace('+', ' ');                                                              // 128
    var binaryData = new Buffer(base64Data, 'base64').toString('binary');                                    // 129
    console.log(path);                                                                                       // 130
    fs.writeFile(path, binaryData, 'binary', function (err) {                                                // 131
      fut1.return(err);                                                                                      // 132
    }); // fs.writeFile(path, data,                                                                          // 133
    //     function (err,res) {                                                                              // 135
    //         if (err) throw err;                                                                           // 136
    //           console.log('Done!');                                                                       // 137
    //           fut1.return(res)                                                                            // 138
    //     }                                                                                                 // 139
    // );                                                                                                    // 140
                                                                                                             //
    return fut1.wait();                                                                                      // 141
  },                                                                                                         // 142
  'publicidades.updateContrato': function (id, data) {                                                       // 143
    return Publicidades.update({                                                                             // 145
      _id: id                                                                                                // 145
    }, {                                                                                                     // 145
      $set: {                                                                                                // 145
        textoContrato: data                                                                                  // 145
      }                                                                                                      // 145
    });                                                                                                      // 145
  },                                                                                                         // 146
  "publicidades.cambiaCampo": function (id, campo, valor) {                                                  // 147
    var data = {};                                                                                           // 149
    data[campo] = valor;                                                                                     // 151
    return Publicidades.update({                                                                             // 152
      _id: id                                                                                                // 152
    }, {                                                                                                     // 152
      $set: data                                                                                             // 152
    });                                                                                                      // 152
  },                                                                                                         // 153
  'users.cargarInicial': function (data) {                                                                   // 154
    var hayUsuarios = Meteor.users.find().count() > 0;                                                       // 155
                                                                                                             //
    if (!hayUsuarios) {                                                                                      // 156
      var perfil = {                                                                                         // 157
        nombres: "alejandro",                                                                                // 157
        rol: "administrador"                                                                                 // 157
      };                                                                                                     // 157
      Accounts.createUser({                                                                                  // 159
        username: "admin",                                                                                   // 159
        password: "admin",                                                                                   // 159
        profile: perfil                                                                                      // 159
      });                                                                                                    // 159
    }                                                                                                        // 160
  },                                                                                                         // 161
  "users.perfil": function (id) {                                                                            // 162
    return Meteor.users.findOne({                                                                            // 164
      _id: id                                                                                                // 164
    }).profile;                                                                                              // 164
  },                                                                                                         // 165
  "publicidades.subirVideo": function (video64, id) {                                                        // 166
    var fs = Npm.require('fs');                                                                              // 168
                                                                                                             //
    console.log(id);                                                                                         // 169
    Future = Npm.require('fibers/future');                                                                   // 170
    var fut1 = new Future();                                                                                 // 171
    var path = process.cwd() + '/../web.browser/app/images/' + id;                                           // 173
    fs.writeFile(path, video64, function (err, res) {                                                        // 175
      if (err) throw err;                                                                                    // 177
      console.log('Done!');                                                                                  // 178
      fut1.return(res);                                                                                      // 179
    });                                                                                                      // 180
    return fut1.wait();                                                                                      // 182
  },                                                                                                         // 183
  "getSitio": function () {                                                                                  // 184
    var sitio = Settings.findOne({                                                                           // 186
      clave: "sitio"                                                                                         // 186
    });                                                                                                      // 186
    if (sitio) return sitio.valor;                                                                           // 187
    console.log(sitio);                                                                                      // 188
    return "no hay sitio";                                                                                   // 189
  },                                                                                                         // 190
  "guardarIndex": function (data, i) {                                                                       // 191
    // var sitio=Settings.findOne({clave:"sitio"});                                                          // 193
    // if(sitio)return Settings.update({clave:"sitio"},{$set:{valor:data}});                                 // 194
    // else return Settings.insert({clave:"sitio",valor:data})                                               // 195
    var fut1 = new Future();                                                                                 // 197
    var sett = Settings.findOne({                                                                            // 198
      clave: "pathImagenes"                                                                                  // 198
    });                                                                                                      // 198
    var path = sett.valor + '/contenido.html';                                                               // 199
    console.log(path);                                                                                       // 200
    if (i == 0) fs.writeFile(path, data, function (err, res) {                                               // 201
      if (err) throw err;                                                                                    // 203
      fut1.return(i + 1);                                                                                    // 204
    });else fs.appendFile(path, data, function (err, res) {                                                  // 205
      if (err) throw err;                                                                                    // 210
      fut1.return(i + 1);                                                                                    // 211
    });                                                                                                      // 212
    return fut1.wait();                                                                                      // 214
  },                                                                                                         // 215
  "publicidades.quitarPromo": function (idPromo, id) {                                                       // 216
    console.log(idPromo, id);                                                                                // 217
    return Publicidades.update({                                                                             // 218
      _id: id                                                                                                // 219
    }, {                                                                                                     // 219
      $pull: {                                                                                               // 220
        "promociones": {                                                                                     // 220
          "_id": idPromo                                                                                     // 220
        }                                                                                                    // 220
      }                                                                                                      // 220
    }, {                                                                                                     // 220
      getAutoValues: false                                                                                   // 221
    } // SIN ESTE PARAMETRO NO QUITA!!                                                                       // 221
    );                                                                                                       // 218
  },                                                                                                         // 223
  'users.list': function (data) {                                                                            // 224
    return Meteor.users.find().fetch();                                                                      // 225
  },                                                                                                         // 226
  'publicidades.all': function () {                                                                          // 227
    return Publicidades.find({});                                                                            // 228
  },                                                                                                         // 229
  'publicidades.promociones': function (principales) {                                                       // 230
    var ordenar = {                                                                                          // 231
      $sort: {                                                                                               // 232
        _id: 1                                                                                               // 233
      }                                                                                                      // 232
    };                                                                                                       // 231
    var filtro = {                                                                                           // 236
      estado: "ACTIVO"                                                                                       // 236
    };                                                                                                       // 236
    if (principales) filtro.muestraSlide = true;                                                             // 237
    var unw = {                                                                                              // 238
      $unwind: "$promociones"                                                                                // 238
    };                                                                                                       // 238
    var match = {                                                                                            // 239
      $match: filtro                                                                                         // 239
    };                                                                                                       // 239
    var proyecto = {                                                                                         // 241
      $project: {                                                                                            // 242
        _id: "$_id",                                                                                         // 243
        idUsuario: "$idUsuario",                                                                             // 244
        detalle: "$detalle",                                                                                 // 245
        estado: "$estado",                                                                                   // 246
        logo: "$logo",                                                                                       // 247
        detallePromocion: "$detalle",                                                                        // 248
        cantidad: "$cantidadDescuento",                                                                      // 249
        muestraSlide: "$muestraSlide",                                                                       // 250
        ahorroEn: "$tipoDescuento",                                                                          // 251
        tieneVideo: "$tieneVideo",                                                                           // 252
        detalleSlide: "$detalleSlide",                                                                       // 253
        imagenBanner: "$imagenBanner",                                                                       // 254
        videoYoutube: "$videoYoutube",                                                                       // 255
        link: "$link"                                                                                        // 256
      }                                                                                                      // 242
    };                                                                                                       // 241
    var look = {                                                                                             // 261
      $lookup: {                                                                                             // 262
        from: "users",                                                                                       // 264
        localField: "idUsuario",                                                                             // 265
        foreignField: "_id",                                                                                 // 266
        as: "usuario"                                                                                        // 267
      }                                                                                                      // 263
    };                                                                                                       // 261
    var pipeline = [proyecto, match, look]; //if(grupo)pipeline.push(grupo)                                  // 270
                                                                                                             //
    var res = Publicidades.aggregate(pipeline);                                                              // 273
    return res;                                                                                              // 275
  },                                                                                                         // 276
  'users.one': function (id) {                                                                               // 277
    return Meteor.users.findOne({                                                                            // 278
      _id: id                                                                                                // 278
    });                                                                                                      // 278
  },                                                                                                         // 279
  'users.add': function (usuario, clave, perfil) {                                                           // 280
    return Accounts.createUser({                                                                             // 281
      username: usuario,                                                                                     // 281
      password: clave,                                                                                       // 281
      profile: perfil                                                                                        // 281
    });                                                                                                      // 281
  },                                                                                                         // 282
  'users.update': function (_id, usuario, perfil) {                                                          // 283
    return Meteor.users.update({                                                                             // 284
      _id: _id                                                                                               // 284
    }, {                                                                                                     // 284
      $set: {                                                                                                // 284
        profile: perfil,                                                                                     // 284
        username: usuario                                                                                    // 284
      }                                                                                                      // 284
    });                                                                                                      // 284
  },                                                                                                         // 285
  'users.remove': function (_id) {                                                                           // 286
    return Meteor.users.remove({                                                                             // 287
      _id: _id                                                                                               // 287
    });                                                                                                      // 287
  },                                                                                                         // 288
  'users.resetPassword': function (_id, clave) {                                                             // 289
    return Accounts.setPassword(_id, clave);                                                                 // 290
  },                                                                                                         // 291
  'settings.generarVariables': function () {                                                                 // 292
    Settings.remove({});                                                                                     // 293
    if (!Settings.findOne({                                                                                  // 294
      clave: "hostInyeccion"                                                                                 // 294
    })) Settings.insert({                                                                                    // 294
      clave: "hostInyeccion",                                                                                // 294
      valor: "192.155.543.5"                                                                                 // 294
    });                                                                                                      // 294
    if (!Settings.findOne({                                                                                  // 295
      clave: "usuarioInyeccion"                                                                              // 295
    })) Settings.insert({                                                                                    // 295
      clave: "usuarioInyeccion",                                                                             // 295
      valor: "root"                                                                                          // 295
    });                                                                                                      // 295
    if (!Settings.findOne({                                                                                  // 296
      clave: "claveInyeccion"                                                                                // 296
    })) Settings.insert({                                                                                    // 296
      clave: "claveInyeccion",                                                                               // 296
      valor: "vertrigo"                                                                                      // 296
    });                                                                                                      // 296
    if (!Settings.findOne({                                                                                  // 297
      clave: "dbInyeccion"                                                                                   // 297
    })) Settings.insert({                                                                                    // 297
      clave: "dbInyeccion",                                                                                  // 297
      valor: "asociacion"                                                                                    // 297
    });                                                                                                      // 297
    if (!Settings.findOne({                                                                                  // 298
      clave: "proxNroLiquidacion"                                                                            // 298
    })) Settings.insert({                                                                                    // 298
      clave: "proxNroLiquidacion",                                                                           // 298
      valor: "1"                                                                                             // 298
    });                                                                                                      // 298
    if (!Settings.findOne({                                                                                  // 299
      clave: "pathImagenes"                                                                                  // 299
    })) Settings.insert({                                                                                    // 299
      clave: "pathImagenes",                                                                                 // 299
      valor: "/var/www/appCai/imagenes/"                                                                     // 299
    });                                                                                                      // 299
    if (!Settings.findOne({                                                                                  // 300
      clave: "dirImagenes"                                                                                   // 300
    })) Settings.insert({                                                                                    // 300
      clave: "dirImagenes",                                                                                  // 300
      valor: "localhost:81"                                                                                  // 300
    });                                                                                                      // 300
  },                                                                                                         // 301
  'settings.remove': function (id) {                                                                         // 302
    return Settings.remove({                                                                                 // 303
      _id: id                                                                                                // 303
    });                                                                                                      // 303
  },                                                                                                         // 304
  'settings.oneClave': function (clave) {                                                                    // 305
    return Settings.findOne({                                                                                // 306
      clave: clave                                                                                           // 306
    });                                                                                                      // 306
  },                                                                                                         // 307
  "settings.autoincrementaNroLiquidacion": function () {                                                     // 308
    console.log("fdd");                                                                                      // 309
    var nuevoValor = Number(Settings.findOne({                                                               // 310
      clave: "proxNroLiquidacion"                                                                            // 310
    }).valor) + 1;                                                                                           // 310
    Settings.update({                                                                                        // 311
      clave: "proxNroLiquidacion"                                                                            // 311
    }, {                                                                                                     // 311
      $set: {                                                                                                // 311
        valor: nuevoValor                                                                                    // 311
      }                                                                                                      // 311
    });                                                                                                      // 311
    console.log("cambio");                                                                                   // 312
  },                                                                                                         // 313
  "remote.syncLiquidacion": function (data) {                                                                // 314
    var Future = Npm.require('fibers/future');                                                               // 316
                                                                                                             //
    var fut1 = new Future();                                                                                 // 317
                                                                                                             //
    var exec = Npm.require("child_process").exec;                                                            // 318
                                                                                                             //
    var path = process.cwd() + '/../web.browser/app/shellPython/syncLiquidacion.py';                         // 319
    var command = "python " + path + " " + data._id;                                                         // 321
    exec(command, function (error, stdout, stderr) {                                                         // 323
      fut1.return(stderr);                                                                                   // 325
    });                                                                                                      // 326
    return fut1.wait();                                                                                      // 327
    return fut1.wait();                                                                                      // 329
  },                                                                                                         // 330
  "remote.syncOs": function () {                                                                             // 331
    Future = Npm.require('fibers/future');                                                                   // 333
    var fut1 = new Future();                                                                                 // 334
                                                                                                             //
    var exec = Npm.require("child_process").exec;                                                            // 335
                                                                                                             //
    var path = process.cwd() + '/../web.browser/app/shellPython/importarOs.py';                              // 337
    var command = "python " + path;                                                                          // 339
    exec(command, function (error, stdout, stderr) {                                                         // 340
      if (error) {                                                                                           // 341
        console.log(error);                                                                                  // 342
        throw new Meteor.Error(500, command + " failed");                                                    // 343
      }                                                                                                      // 344
                                                                                                             //
      console.log(stdout);                                                                                   // 345
      fut1.return(stdout.toString());                                                                        // 346
    });                                                                                                      // 347
    return fut1.wait();                                                                                      // 348
    return fut1.wait();                                                                                      // 350
  },                                                                                                         // 351
  'liquidaciones.one': function (id) {                                                                       // 352
    return Liquidaciones.findOne({                                                                           // 354
      _id: id                                                                                                // 354
    });                                                                                                      // 354
  },                                                                                                         // 355
  'liquidaciones.remove': function (id) {                                                                    // 356
    return Liquidaciones.remove({                                                                            // 358
      _id: id                                                                                                // 358
    });                                                                                                      // 358
  },                                                                                                         // 359
  "liquidaciones.updateFactura": function (data, res) {                                                      // 360
    console.log(data);                                                                                       // 361
    console.log(res);                                                                                        // 362
    return true;                                                                                             // 363
  },                                                                                                         // 364
  'liquidaciones_factura.remove': function (idLiquidacion, id) {                                             // 365
    return Liquidaciones.update({                                                                            // 366
      _id: idLiquidacion                                                                                     // 367
    }, {                                                                                                     // 367
      $pull: {                                                                                               // 368
        "facturas": {                                                                                        // 368
          "_id": id                                                                                          // 368
        }                                                                                                    // 368
      }                                                                                                      // 368
    }, {                                                                                                     // 368
      getAutoValues: false                                                                                   // 369
    } // SIN ESTE PARAMETRO NO QUITA!!                                                                       // 369
    );                                                                                                       // 366
  }                                                                                                          // 371
});                                                                                                          // 23
                                                                                                             //
if (Meteor.isServer) {                                                                                       // 374
  Meteor.publish('liquidaciones.all', function (usuario) {                                                   // 376
    if (usuario) {                                                                                           // 378
      if (usuario.profile.rol === "secretaria") return Liquidaciones.find({                                  // 379
        idUsuario: usuario._id                                                                               // 379
      });                                                                                                    // 379
      return Liquidaciones.find();                                                                           // 380
    }                                                                                                        // 381
                                                                                                             //
    return [];                                                                                               // 382
  });                                                                                                        // 384
  Meteor.publish('publicidades.all', function () {                                                           // 385
    return Publicidades.find({}, {                                                                           // 386
      logo: 0                                                                                                // 386
    });                                                                                                      // 386
  });                                                                                                        // 387
  Meteor.publish('nomencladores.one', function (idNomenclador) {                                             // 388
    var res = Nomencladores.find({                                                                           // 389
      _id: Number(idNomenclador)                                                                             // 389
    });                                                                                                      // 389
    return res;                                                                                              // 390
  });                                                                                                        // 391
  Meteor.publish('settings.all', function () {                                                               // 392
    return Settings.find();                                                                                  // 393
  });                                                                                                        // 394
}                                                                                                            // 395
///////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]}},{"extensions":[".js",".json"]});
require("./lib/collections.js");
require("./lib/router.js");
require("./lib/utils.js");
require("./server/main.js");
//# sourceMappingURL=app.js.map
